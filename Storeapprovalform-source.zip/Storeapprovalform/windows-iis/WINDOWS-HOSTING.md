# Windows hosting

Application: https://mis-sweetdreams.in/Storeapprovalform/
Login: https://mis-sweetdreams.in/Storeapprovalform/login.html
IIS site: CFO
Existing IIS sub-application: /Storeapprovalform
Application pool: Storeapprovalform (.NET Framework 4.8, Integrated)
Physical folder: C:\inetpub\wwwroot\CFOProject\Storeapprovalform
Verified: 16 October 2026.

Use this exact existing folder directly. Do not add an iis subfolder, create a second project folder, recreate the standalone storeapproval.mis-sweetdreams.in site, or overwrite App_Data with template data. The temporary standalone IIS site was removed after the main-domain sub-application passed verification. Other applications and the main site's bindings remain unchanged.

Deploy the runtime files from windows-iis/public into the existing folder. Application assets, API requests, navigation, uploads and login redirects resolve relative to /Storeapprovalform/. Authentication cookies are Secure, HttpOnly, SameSite=Strict and scoped to the sub-application path. HTTPS uses the main domain's existing valid certificate. API requests over HTTP redirect to the main-domain HTTPS address.

Existing accounts, the saved store, settings and uploaded files were moved from the pre-existing iis/App_Data into App_Data in this folder, with account/store file checksums verified. The now-empty iis subfolder was removed. No duplicate project folder was created. The old ITMCS folder was not modified or activated. A restricted recovery archive is stored outside the website under C:\ProgramData\StoreApprovalRepair-6bb7a871-9707-4b76-b4dc-73017acac18d.zip.

App_Data holds protected JSON records, salted PBKDF2-HMAC-SHA256 password hashes and uploaded files. Back it up. Never expose it as a separate virtual directory. The application pool has modify access to App_Data and read access to runtime files. Source directories are hidden by IIS request filtering, directory browsing is disabled, and inherited custom headers are replaced safely.

Updates include editable numeric inputs, Save draft and Draft stores, accept/reject decisions, recoverable deletion/restoration, editable submitted revisions that retain earlier snapshots and require fresh approvals, and later LOI/agreement uploads by authorized workspace members. Drafts can retain incomplete investment amounts; submission enforces full calculation constraints.

Verified public HTTPS home, login and assets returned 200; anonymous API and deliberately invalid login returned 401; private account/source-file requests were blocked. Disposable server-side workflow checks passed for draft/submission validation, revision snapshots, delete/restore, non-owner deletion rejection, and rejection reason/history. Real store records were not used for workflow tests.
