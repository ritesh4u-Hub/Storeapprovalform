import './globals.css';
export const metadata={title:'Store Approval Desk',description:'Store profitability projections and approvals'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
