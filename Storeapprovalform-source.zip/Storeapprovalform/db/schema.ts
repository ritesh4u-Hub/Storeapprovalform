import {sqliteTable,text,integer} from 'drizzle-orm/sqlite-core';
export const settings=sqliteTable('settings',{id:text('id').primaryKey(),data:text('data').notNull()});
export const proposals=sqliteTable('proposals',{id:text('id').primaryKey(),data:text('data').notNull(),version:integer('version').notNull().default(1)});
