'use client';

import {useEffect, useRef, useState, type InputHTMLAttributes} from 'react';

type Props = Omit<InputHTMLAttributes<HTMLInputElement>, 'value' | 'onChange' | 'type'> & {
  value: number | null | undefined;
  onValueChange: (value: number | null) => void;
  emptyValue?: number | null;
};

export default function NumberInput({value, onValueChange, emptyValue = 0, ...props}: Props) {
  const [text, setText] = useState(String(value ?? ''));
  const editing = useRef(false);

  useEffect(() => {
    if (!editing.current) setText(String(value ?? ''));
  }, [value]);

  return <input {...props} type="number" value={text}
    onFocus={event => {
      editing.current = true;
      event.currentTarget.select();
      props.onFocus?.(event);
    }}
    onChange={event => {
      const next = event.currentTarget.value;
      setText(next);
      onValueChange(next === '' ? emptyValue : Number(next));
    }}
    onBlur={event => {
      editing.current = false;
      setText(String(value ?? ''));
      props.onBlur?.(event);
    }}/>
}
