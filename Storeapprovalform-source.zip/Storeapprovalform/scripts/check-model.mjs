import assert from 'node:assert/strict';
import {calculate,defaults,validate} from '../lib/model.ts';
const p={...defaults,name:'Verification store',perSqft:2555418/699};validate(p);const c=calculate(p);
assert.equal(Math.round(c[0].mrp),1153846);assert.equal(Math.round(c[0].nsv),841121);
assert.equal(c[0].rent,139700);assert.ok(c[1].rent>139700);assert.equal(c[0].cc,13500);assert.equal(c[0].staff,13500);
assert.equal(c.reduce((s,y)=>s+y.preop*12,0),83832);assert.equal(c[4].preop,0);
assert.ok(Math.abs(c[0].depreciation*60-100000)<0.001);assert.equal(Math.round(c[0].fprofit),34768);
assert.ok(Math.abs(c[0].fdep*60-p.franchiseeCapex)<0.001);assert.equal(c[0].book,p.franchiseeCapex);
assert.ok(Math.abs(c[4].book-p.franchiseeCapex/5)<0.001);assert.equal(c[0].roi.toFixed(1),'12.1');
assert.throws(()=>validate({...p,discount:100}));assert.throws(()=>validate({...p,franchiseeCapex:99999999}));
console.log('Financial checks passed: MRP, GST, higher-of rent, staff/CC, one-time expense, both depreciation schedules and reference franchisee ROI.');

const overrides={...p,opsYears:{...p.opsYears,manpower:[null,null,90000,null,0]}};const v=calculate(overrides);assert.equal(v[1].opmanpower,82950);assert.equal(v[2].opmanpower,90000);assert.equal(v[3].opmanpower,94500);assert.equal(v[4].opmanpower,0);console.log('Year-specific cost overrides, automatic escalation, cascade and explicit zero checked.');
